package Scrips;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.TestListenerAdapter;
import org.testng.TestNG;
import org.testng.collections.Lists;

public class Testng_Launcher {

	public static void main(String[] args) throws InterruptedException, IOException {
		
		
		String[][] Mydata=readXLSX("C:\\Users\\Admin\\Desktop\\Data_Compare\\resources\\Driver.xlsx","Data");
		
		String path="C:\\Users\\Admin\\Desktop\\Data_Compare\\resources\\Testng.xml";
		
		PrintWriter writer=new PrintWriter(path);
		writer.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		writer.println("<!DOCTYPE suite SYSTEM \"http://testng.org/testng-1.0.dtd\" >");
		writer.println("<suite name=\"DVD Automation\">");

		for (int i=1;i<Mydata[0].length;i++) {
			String Type1=Mydata[0][i];
			String Type2=Mydata[1][i];
			String Type3=Mydata[2][i];
			
			writer.println("<test name=\""+Type1+"_"+Type2+"\" >");
			writer.println("<parameter name=\"Source\" value=\""+Type1+"\" />");
			writer.println("<parameter name=\"Target\" value=\""+Type2+"\" />");
			writer.println("<classes>");
			writer.println("<class name=\"Scrips.Launcher\"/>");
			writer.println("</classes>");
			writer.println(" </test>");
		}
		writer.println("</suite>");
		writer.close();
		Thread.sleep(3000);
		
		
		TestListenerAdapter tla=new TestListenerAdapter();
		TestNG testng = new TestNG();
		testng.setOutputDirectory("C:\\Users\\Admin\\Desktop\\Data_Compare\\Result\\Test-output\\");
		List<String> suites=Lists.newArrayList();
		suites.add(path);
		testng.setTestSuites(suites);
		testng.run();
	}
	
	
	 public static String[][] readXLSX(String Filepath,String Sheet) throws IOException{    	 
	  		File excel=new File(Filepath);  		
	  		FileInputStream fis=new FileInputStream(excel);  		
	  		String Value=null;
	  		XSSFWorkbook book=new XSSFWorkbook(fis);  		
	  		XSSFSheet ws=book.getSheet(Sheet);  		
	  		XSSFCell cell;  		
	  		DataFormatter format=new DataFormatter();
	  		int rowNum=ws.getLastRowNum()+1;
	  		int colNum=ws.getRow(0).getLastCellNum();
	  		
	  		String[][] Parameter=new String[(colNum)][(rowNum)];
	  		for(int i=0;i<rowNum;i++){
	  			XSSFRow row=ws.getRow(i);
	  			for(int j=0;j<colNum;j++){
	  				
	  				cell=row.getCell(j);
	  				if(!(cell==null)){
	  					Value=format.formatCellValue(cell);
	  				}
	  				else{
	  					Value=null;
	  				}
	  				Parameter[j][i]=Value;
	  			}
	  			
	  		}
	  		book.close();
	  		return Parameter;
	  		
	  	}


}
