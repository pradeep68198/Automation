package Scrips;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.util.Strings;

public class Launcher extends Compare_Function{
	
	public SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
	public String Scenario,RQM_Sta,Exe_Sta,sheet_name;
	public int col;
	public Properties prob;
	
  @Test
  @Parameters({"Source","Target"})
  
  public void Compare_Scripts(String S, String T) throws Exception{
	  
	  System.setProperty("java.library.path","C:\\Users\\Admin\\Desktop\\Data_Compare\\resources\\dll");
	  Field fieldSysPath=ClassLoader.class.getDeclaredField("sys_paths");
	  fieldSysPath.setAccessible(true);
	  fieldSysPath.set(null,null);
	  
	  identifier(S,T);
	  
	  
	  for(int i=1; i<source[0].length; i++) {
		  if(Src_DB.equalsIgnoreCase("Hive")) {
			  Scenario=source[0][i];
			  
			  if(Strings.isNullOrEmpty(source[4][i])) {
				  Src_Query = new String (Files.readAllBytes(Paths.get(Query_File+source[5][i])));
				  
			  }
			  else
			  {
				  Src_Query=source[4][i];
			  }
			  
			  Src_Username=source[1][i];
			  Src_Password=source[2][i];
			  Src_Host=source[3][i];
			  Exe_Sta=source[6][i];
			  sheet_name="Hive";
			  col=6;
		  }
		
		  if(Src_DB.equalsIgnoreCase("Excel")) {
			  Scenario=source[0][i];
			  
			  Input_File_Path_Source=source[1][i];
			  Src_excel_Sheet_name=source[2][i];
			  Exe_Sta=source[3][i];
			  sheet_name="Excel";
			  col=3;
}
		  
		  if(Src_DB.equalsIgnoreCase("SQL Server")) {
			  
			  
			  if(Strings.isNullOrEmpty(source[5][i])) {
				  Src_Query = new String (Files.readAllBytes(Paths.get(Query_File+source[6][i])));
				  
			  }
			  else
			  {
				  Src_Query=source[5][i];
			  }
			  Scenario=source[0][i];
			  Src_Username=source[1][i];
			  Src_Password=source[2][i];
			  Src_Server_name=source[3][i];
			  Src_DB_Name=source[4][i];
			  Exe_Sta=source[6][i];
			  sheet_name="SQL Server";
			  col=6;
		  }
		  
if(Src_DB.equalsIgnoreCase("DB2")) {
			  
			  
			  if(Strings.isNullOrEmpty(source[6][i])) {
				  Src_Query = new String (Files.readAllBytes(Paths.get(Query_File+source[7][i])));
				  
			  }
			  else
			  {
				  Src_Query=source[6][i];
			  }
			  Scenario=source[0][i];
			  Src_Username=source[1][i];
			  Src_Password=source[2][i];
			  
			  Src_DB_Name=source[3][i];
			  Src_Host=source[4][i];
			  Src_Port=source[5][i];
			  Exe_Sta=source[8][i];
			  sheet_name="DB2";
			  col=8;
		  }
if(Src_DB.equalsIgnoreCase("Netezza")) {
	  
	  
	  if(Strings.isNullOrEmpty(source[5][i])) {
		  Src_Query = new String (Files.readAllBytes(Paths.get(Query_File+source[6][i])));
		  
	  }
	  else
	  {
		  Src_Query=source[5][i];
	  }
	  Scenario=source[0][i];
	  Src_Username=source[1][i];
	  Src_Password=source[2][i];
	  
	  Src_DB_Name=source[3][i];
	  Src_Server_name=source[4][i];
	  Exe_Sta=source[7][i];
	  sheet_name="Netezza";
	  col=7;
}

if(Src_DB.equalsIgnoreCase("Delimiter")) {
	Scenario=source[0][i];
	
	Input_File_Path_Source=source[1][i];
	if(source[4][i].equalsIgnoreCase("Tab")) {
		Src_Symbol="\\t";
	}
	else if(source[4][i].equalsIgnoreCase("CSV")) {
		Src_Symbol=",";
	}
	else if(source[4][i].equalsIgnoreCase("Pipe")) {
		Src_Symbol="\\|";
	}
	else {
		Src_Symbol=source[4][i];
	}
	
	Src_Header=source[2][i];
	Src_Footer=source[3][i];
	Exe_Sta=source[5][i];
	sheet_name="File";
	col=5;
}

if(Strings.isNullOrEmpty(Exe_Sta)) {
	if(Tgt_DB.equalsIgnoreCase("Hive")) {
		for(int j=1;j<target[0].length;j++) {
			if(target[0][j].equalsIgnoreCase(Scenario)) {
				  if(Strings.isNullOrEmpty(target[4][j])) {
					  Tgt_Query = new String (Files.readAllBytes(Paths.get(Query_File+target[7][j])));
					  
				  }
				  else
				  {
					  Tgt_Query=target[4][j];
				  }
				  
				  Tgt_Username=target[1][j];
				  Tgt_Password=target[2][j];
				  Tgt_Host=target[3][j];
				  
Key_col_function(target[5][j],target[6][j]);
break;
		
			}
		}
	}
	
	if(Tgt_DB.equalsIgnoreCase("SQL Server")) {
		for(int j=1;j<target[0].length;j++) {
			if(target[0][j].equalsIgnoreCase(Scenario)) {
				  if(Strings.isNullOrEmpty(target[5][j])) {
					  Tgt_Query = new String (Files.readAllBytes(Paths.get(Query_File+target[8][j])));
					  
				  }
				  else
				  {
					  Tgt_Query=target[5][j];
				  }
				  
				  Tgt_Username=target[1][j];
				  Tgt_Password=target[2][j];
				  Tgt_Server_name=target[3][j];
				  Tgt_DB_Name=target[4][j];
				  
Key_col_function(target[6][j],target[7][j]);
break;
		
			}
		}
	}
	
	if(Tgt_DB.equalsIgnoreCase("DB2")) {
		for(int j=1;j<target[0].length;j++) {
			if(target[0][j].equalsIgnoreCase(Scenario)) {
				  if(Strings.isNullOrEmpty(target[6][j])) {
					  Tgt_Query = new String (Files.readAllBytes(Paths.get(Query_File+target[9][j])));
					  
				  }
				  else
				  {
					  Tgt_Query=target[6][j];
				  }
				  
				  Tgt_Username=target[1][j];
				  Tgt_Password=target[2][j];
				  
				  Tgt_DB_Name=target[3][j];
				  Tgt_Host=target[4][j];
				  Tgt_Port=target[5][j];
				  
Key_col_function(target[7][j],target[8][j]);
break;
		
			}
		}
	}
	
	if(Tgt_DB.equalsIgnoreCase("Netezza")) {
		for(int j=1;j<target[0].length;j++) {
			if(target[0][j].equalsIgnoreCase(Scenario)) {
				  if(Strings.isNullOrEmpty(target[5][j])) {
					  Tgt_Query = new String (Files.readAllBytes(Paths.get(Query_File+target[8][j])));
					  
				  }
				  else
				  {
					  Tgt_Query=target[5][j];
				  }
				  
				  Tgt_Username=target[1][j];
				  Tgt_Password=target[2][j];
				  
				  Tgt_DB_Name=target[3][j];
				  Tgt_Server_name=target[4][j];
				  
				  
Key_col_function(target[6][j],target[7][j]);
break;
		
			}
		}
	}
	
	if(Tgt_DB.equalsIgnoreCase("Delimiter")) {
		for(int j=1;j<target[0].length;j++) {
			if(target[0][j].equalsIgnoreCase(Scenario)) {
				Input_File_Path_Target=target[1][j];
				if(target[4][i].equalsIgnoreCase("Tab")) {
					Tgt_Symbol="\\t";
				}
				else if(target[4][j].equalsIgnoreCase("CSV")) {
					Tgt_Symbol=",";
				}
				else if(target[4][j].equalsIgnoreCase("Pipe")) {
					Tgt_Symbol="\\|";
				}
				else {
					Tgt_Symbol=target[4][j];
				}
				
				Tgt_Header=target[2][j];
				Tgt_Footer=target[3][j];

				Key_col_function(target[5][j],target[6][j]);
				break;
						
							}
						}
					}

	if(Tgt_DB.equalsIgnoreCase("Excel")) {
		for(int j=1;j<target[0].length;j++) {
			if(target[0][j].equalsIgnoreCase(Scenario)) {
				Input_File_Path_Target=target[1][j];
								
				Tgt_excel_Sheet_name=target[4][j];
				

				Key_col_function(target[2][j],target[3][j]);
				break;
						
							}
						}
					}
				
	Result_File=RR_Path+S+"_"+T+"_"+Scenario+"_"+formatter.format(new Date())+".xlsx";
	Create_workbook_Sheets();
	launch();
	status=true;
	
	Cleaner();
	
	writeXLSX(Source_excel,sheet_name,"Yes",col,i);
}
  }
}
  }